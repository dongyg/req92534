---
layout: page
title: Service type (Areas)
---

{% include JB/setup %}

{% include service_type %}

This service type is for _areas_, and [full documentation is available here](/documentation/1.0/area.html). 