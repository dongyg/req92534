---
layout: page
title: Service type (Events)
---

{% include JB/setup %}

{% include service_type %}

This service type is for _road events_, and [full documentation is available here](/documentation/1.0/event.html).