---
layout: page
title: Service type (Events)
---

{% include JB/setup %}

{% include service_type %}

This service type is for _road events_, and [full documentation is available here](/documentation/1.0/event.html). This particular service type is for the _static_ version of the service, so the interactive filters and query parameters described in the linked documentation are not supported.